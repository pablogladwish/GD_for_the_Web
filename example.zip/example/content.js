// replace images when the page loads
$('img').attr('src', 'https://68.media.tumblr.com/9dbfc726e0263c887ab5ab71fca13cfb/tumblr_ood0yvG2NB1uh83dto1_250.png');

// replace text in the page when it loads
$('body').children().each(function () {
	// replace the '@' sign with a '$' sign
	$(this).html( $(this).html().replace(/WeChat/g,'Government Surveillance Network') );
});



// when you click on the page 'body' apply .gradient to it from the CSS
$('body').click(function() {
	$('img').attr('src', 'http://68.media.tumblr.com/463178184741ba684d5e37cc592b8f65/tumblr_ood4kaXOtE1uh83dto1_1280.gif');

});




